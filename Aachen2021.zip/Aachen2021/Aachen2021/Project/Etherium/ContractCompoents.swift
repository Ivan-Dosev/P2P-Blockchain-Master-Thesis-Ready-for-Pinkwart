import Foundation


enum ContractMethods:  String {

    case writeContract    = "saveContractParticipants"
    case readSenderName   = "getSenderName"
    case readReceiverName = "getReceiverName"
    case readObserverName = "getObserverNames"
}

let contractAddress = "0xF6EF5d30c04FaaDdaFd37135754fecE685424888"

let contractABI =
    """
 [
     {
         "inputs": [],
         "name": "getObserverNames",
         "outputs": [
             {
                 "internalType": "string",
                 "name": "",
                 "type": "string"
             }
         ],
         "stateMutability": "view",
         "type": "function"
     },
     {
         "inputs": [],
         "name": "getReceiverName",
         "outputs": [
             {
                 "internalType": "string",
                 "name": "",
                 "type": "string"
             }
         ],
         "stateMutability": "view",
         "type": "function"
     },
     {
         "inputs": [],
         "name": "getSenderName",
         "outputs": [
             {
                 "internalType": "string",
                 "name": "",
                 "type": "string"
             }
         ],
         "stateMutability": "view",
         "type": "function"
     },
     {
         "inputs": [
             {
                 "internalType": "string",
                 "name": "newSenderName",
                 "type": "string"
             },
             {
                 "internalType": "string",
                 "name": "newReceiverName",
                 "type": "string"
             },
             {
                 "internalType": "string",
                 "name": "newObserverNames",
                 "type": "string"
             }
         ],
         "name": "saveContractParticipants",
         "outputs": [],
         "stateMutability": "nonpayable",
         "type": "function"
     }
 ]
"""
