
import Foundation

enum Network {
    case rinkeby
    case ropsten
    case ganache
}
