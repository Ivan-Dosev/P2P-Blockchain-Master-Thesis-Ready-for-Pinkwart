//
//  ContentView.swift
//  Aachen2021
//
//  Created by Ivan Dimitrov on 10.05.21.
//

import SwiftUI
import CoreData

struct ContentView: View {


    var body: some View {
        VStack {
            FirstProView()
        }

    }


}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
