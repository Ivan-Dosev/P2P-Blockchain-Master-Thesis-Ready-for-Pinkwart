//
//  CryptoData_Array+CoreDataClass.swift
//  Aachen2021
//
//  Created by Ivan Dimitrov on 10.05.21.
//
//

import Foundation
import CoreData

@objc(CryptoData_Array)
public class CryptoData_Array: NSManagedObject {

}
